def main():
    # Ecrivez votre code ici !
    # Attention tout votre code doit être indenté comme ce commentaire


# Ne touchez pas le code ci-dessous
if __name__ == "__main__":
    main()