# Dans le fichier `operations.py` , on peut définir les fonctions addition et multiplication

def addition(a, b):
    return a + b


def multiplication(a, b):
    return a * b