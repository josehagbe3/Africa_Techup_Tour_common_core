# Instructions 

Dans cette exercice, vous allez écrire directement dans un fichier python qui se nomme `main.py`.

  1. Utilisez la fonctions `print` pour afficher la phrase `"J'apprends Python !"`
  2. Calculez le résultat de `17 + 35 * 2` et affichez le résultat (Vous pouvez placer le calcul directement dans la fonction `print` pour l'afficher)