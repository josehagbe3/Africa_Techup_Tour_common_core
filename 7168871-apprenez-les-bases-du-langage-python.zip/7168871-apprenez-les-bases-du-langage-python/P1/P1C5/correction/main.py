# Créer les quatres variables
nom = "Jean"
age = 25
taille = 1.80
est_etudiant = True

# Afficher les valeurs des quatres variables
print(f"Nom: {nom}")
print(f"Age: {age}")
print(f"Taille: {taille}")
print(f"Est étudiant: {est_etudiant}")

# Afficher les types des quatres variables
print(f"Type nom: {type(nom)}")
print(f"Type age: {type(age)}")
print(f"Type taille: {type(taille)}")
print(f"Type est étudiant: {type(est_etudiant)}")