# Instructions  

1. Créez une variable nommée `nom` et attribuez-y votre **nom**.
2. Créez une variable nommée `age` et attribuez-y votre **âge**.
3. Affichez une phrase contenant votre **nom** et votre **âge** en utilisant les variables que vous venez de créer. Par exemple, `"Je m'appelle Jean et j'ai 25 ans."` (Utilisez le f-string)
4. Modifiez la valeur de la variable age pour ajouter **10 ans** à votre **âge** actuel.
5. Affichez à nouveau la phrase contenant votre **nom** et votre **âge** en utilisant les variables mises à jour. Par exemple, `"Je m'appelle Jean et j'ai 35 ans maintenant."` (Utilisez le f-string)